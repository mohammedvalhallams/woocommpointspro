<?php
/**
 * Silence is golden.
 *
 * @link       https://makewebbetter.com/
 * @since      1.0.0
 * @package    Points and Rewards for WooCommerce Pro
 */

esc_html_e( 'oops looks like nothing is here', 'ultimate-woocommerce-points-and-rewards' );
